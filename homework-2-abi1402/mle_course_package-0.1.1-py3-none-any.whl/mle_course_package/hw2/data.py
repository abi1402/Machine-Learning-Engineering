import torch
from torch.utils.data import Dataset
import numpy as np
import os


class AssignmentDataset(Dataset):
    def __init__(self, root_dir):
        self.root_dir = root_dir
        self.files = [f for f in os.listdir(root_dir) if f.endswith(".npy")]
        self.classes = [f.replace(".npy", "") for f in self.files]

        self.data = []
        self.labels = []

        for label, file in enumerate(self.files):
            file_path = os.path.join(root_dir, file)
            class_data = np.load(file_path)  # shape: (N, 784)

            for sample in class_data:
                self.data.append(sample)
                self.labels.append(label)

        self.data = torch.tensor(np.array(self.data), dtype=torch.float32)
        self.labels = torch.tensor(self.labels, dtype=torch.long)

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        x = self.data[idx] / 255.0  # normalize
        y = self.labels[idx]
        return x, y


class DatasetInterpret(Dataset):
    """
    Dataset for Model Interpretation questions.
    """

    def __init__(self, root_dir, percentage=0.5):
        data_dir = os.path.join(root_dir, "data", "activation")
        self.samples = []
        self.classes = sorted(os.listdir(data_dir))

        for label, cls in enumerate(self.classes):
            data = np.load(os.path.join(data_dir, cls))
            num_samples = int(len(data) * percentage)
            subset = data[:num_samples]
            for img in subset:
                self.samples.append((img, label))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        img, label = self.samples[idx]
        img = torch.from_numpy(img.reshape(28, 28)).float() / 255.0
        return img.unsqueeze(0), label


class DatasetAugmentationTrain(Dataset):
    def __init__(self, root_dir, transform=None):
        self.samples = []
        self.transform = transform

        data_dir = os.path.join(root_dir, "data", "augmentation")
        all_files = os.listdir(data_dir)
        split_files = [f for f in all_files if f.startswith("train_")]
        class_names = []
        for f in split_files:
            class_name = f.replace("train_", "").replace(".npy", "")
            class_names.append(class_name)

        self.classes = sorted(list(set(class_names)))
        self.class_to_idx = {cls: i for i, cls in enumerate(self.classes)}

        for f in split_files:
            class_name = f.replace("train_", "").replace(".npy", "")
            label = self.class_to_idx[class_name]

            file_path = os.path.join(data_dir, f)
            data = np.load(file_path)

            for img in data:
                self.samples.append((img, label))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        img, label = self.samples[idx]
        # Already normalized
        # img = torch.from_numpy(img.reshape(28, 28)).float() / 255.0
        img = torch.from_numpy(img.reshape(28, 28)).float()
        img = img.unsqueeze(0) 
        if self.transform:
            img = self.transform(img)
        return img, label


class DatasetAugmentationTest(Dataset):
    def __init__(self, root_dir, transform=None):
        self.samples = []
        self.transform = transform
        self.classes = []

        data_dir = os.path.join(root_dir, "data", "augmentation")
        all_files = os.listdir(data_dir)
        # Look for test files instead of train files
        split_files = [f for f in all_files if f.startswith("test_")]
        
        class_names = []
        for f in split_files:
            class_name = f.replace("test_", "").replace(".npy", "")
            class_names.append(class_name)

        self.classes = sorted(list(set(class_names)))
        self.class_to_idx = {cls: i for i, cls in enumerate(self.classes)}

        for f in split_files:
            class_name = f.replace("test_", "").replace(".npy", "")
            label = self.class_to_idx[class_name]

            file_path = os.path.join(data_dir, f)
            data = np.load(file_path)

            for img in data:
                self.samples.append((img, label))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        img, label = self.samples[idx]
        # Already normalized
        # img = torch.from_numpy(img.reshape(28, 28)).float() / 255.0
        img = torch.from_numpy(img.reshape(28, 28)).float()
        img = img.unsqueeze(0)
        
        if self.transform:
            img = self.transform(img)
        return img, label


# This is used to load the datasets used in Diana's questions: Review and Evaluation
class Dataset_RE(Dataset):
    """
    Define a custom PyTorch Dataset class. The class loads and preprocesses the
    Dataset_RE dataset, making it compatible with PyTorch's DataLoader for
    training neural networks.
    """

    def __init__(self, root_dir):
        self.samples = []
        self.classes = sorted(os.listdir(root_dir))

        for label, cls in enumerate(self.classes):
            data = np.load(os.path.join(root_dir, cls))
            for img in data:
                self.samples.append((img, label))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        img, label = self.samples[idx]
        img = torch.from_numpy(img.reshape(28, 28)).float() / 255.0
        return img.unsqueeze(0), label
