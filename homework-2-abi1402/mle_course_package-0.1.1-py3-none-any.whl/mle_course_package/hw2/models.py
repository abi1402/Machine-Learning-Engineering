##############
### Models ###
##############

import torch.nn as nn
import torch.nn.functional as F


class SimpleCNNModel(nn.Module):
    def __init__(self, num_classes):
        super().__init__()

        self.conv1 = nn.Conv2d(1, 32, 3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, 3, padding=1)

        self.fc1 = nn.Linear(64 * 28 * 28, 128)
        self.fc2 = nn.Linear(128, num_classes)

    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = F.relu(self.conv2(x))
        x = x.view(x.size(0), -1)
        x = F.relu(self.fc1(x))
        return self.fc2(x)


####### For Optimizer & Activation related questions #######
class MLP_F1_G1(nn.Module):
    """
    Deep Fully Connected Network for classification.

    Args:
        input_dim: Dimension of input features (784 for 28x28 images)
        num_classes: Number of output classes (we sample 20 classes from the quickdraw dataset)
        activation_fn: Activation function class (example: nn.ReLU, nn.Sigmoid)
        hidden_dim: Number of units in each hidden layer (default: 256)
        num_layers: Number of hidden layers (default: 10)
        dropout: Dropout probability (default: 0.1)
    """

    def __init__(
        self,
        input_dim,
        num_classes,
        activation_fn,
        hidden_dim=256,
        num_layers=10,
        dropout=0.1,
    ):
        super().__init__()

        layers = []
        in_dim = input_dim

        # Build hidden layers
        for _ in range(num_layers):
            layers.extend(
                [
                    nn.Linear(in_dim, hidden_dim),
                    nn.BatchNorm1d(hidden_dim),
                    activation_fn(),
                    nn.Dropout(dropout),
                ]
            )
            in_dim = hidden_dim

        # Output layer
        layers.append(nn.Linear(hidden_dim, num_classes))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        """Forward pass through the network."""
        return self.net(x)


class MLP_E1(nn.Module):
    """Model for confusion matrix interpretation questions"""

    def __init__(self, num_classes, dropout=0.2):
        super().__init__()

        self.fc1 = nn.Linear(28 * 28, 256)
        self.bn1 = nn.BatchNorm1d(256)

        self.fc2 = nn.Linear(256, 256)
        self.bn2 = nn.BatchNorm1d(256)

        self.fc3 = nn.Linear(256, 128)
        self.bn3 = nn.BatchNorm1d(128)

        self.fc4 = nn.Linear(128, num_classes)

        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        x = x.view(x.size(0), -1)

        x = self.dropout(F.relu(self.bn1(self.fc1(x))))
        x = self.dropout(F.relu(self.bn2(self.fc2(x))))
        x = self.dropout(F.relu(self.bn3(self.fc3(x))))

        x = self.fc4(x)
        return x


class MLP_conf(nn.Module):
    def __init__(self, num_classes, dropout=0.2):
        super().__init__()

        self.fc1 = nn.Linear(28 * 28, 256)
        self.bn1 = nn.BatchNorm1d(256)

        self.fc2 = nn.Linear(256, 256)
        self.bn2 = nn.BatchNorm1d(256)

        self.fc3 = nn.Linear(256, 128)
        self.bn3 = nn.BatchNorm1d(128)

        self.fc4 = nn.Linear(128, num_classes)

        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        x = x.view(x.size(0), -1)

        x = self.dropout(F.relu(self.bn1(self.fc1(x))))
        x = self.dropout(F.relu(self.bn2(self.fc2(x))))
        x = self.dropout(F.relu(self.bn3(self.fc3(x))))

        x = self.fc4(x)
        return x
