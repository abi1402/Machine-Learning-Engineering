import torch
from torch.utils.data import random_split, DataLoader
from torch.optim import Adam
from tqdm.auto import tqdm
import numpy as np

# list of classes
FINAL_CLASSES = [
    "backpack",
    "dog",
    "cat",
    "key",
    "fish",
    "horse",
    "pizza",
    "clock",
    "donut",
    "airplane",
    "umbrella",
    "mug",
    "t-shirt",
    "flower",
    "tree",
    "church",
    "teddy-bear",
    "The Mona Lisa",
    "yoga",
    "remote control",
]

N_CLASSES = len(FINAL_CLASSES)


def train_model(
    model,
    dataset,
    criterion,
    batch_size,
    device,
    epochs=10,
    optimizer=None,
    learning_rate=1e-3,
):
    train_size = int(0.7 * len(dataset))
    validation_size = int(0.2 * len(dataset))
    test_size = len(dataset) - train_size - validation_size

    train_dataset, validation_dataset, test_dataset = random_split(
        dataset, [train_size, validation_size, test_size]
    )

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)

    validation_loader = DataLoader(
        validation_dataset, batch_size=batch_size, shuffle=False
    )

    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

    if optimizer is None:
        optimizer = Adam(model.parameters(), lr=learning_rate)

    # Store history for plotting
    history = {
        "train_accuracy": [],
        "val_accuracy": [],
        "train_loss": [],
        "val_loss": [],
    }

    for epoch in tqdm(range(epochs)):
        model.train()
        train_loss = 0.0
        train_correct = 0
        train_total = 0

        for imgs, labels in tqdm(train_loader):
            imgs = imgs.to(device)
            labels = labels.to(device)

            optimizer.zero_grad()
            outputs = model(imgs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            train_loss += loss.item() * imgs.size(0)
            _, preds = outputs.max(1)
            train_correct += preds.eq(labels).sum().item()
            train_total += labels.size(0)

        train_loss /= train_total
        train_acc = train_correct / train_total

        validation_loss, validation_acc = evaluate(
            model, validation_loader, criterion, device
        )  # validate on val data not training

        # Store values in history
        history["train_accuracy"].append(train_acc)
        history["val_accuracy"].append(validation_acc)
        history["train_loss"].append(train_loss)
        history["val_loss"].append(validation_loss)
        print(
            f"Epoch {epoch+1}/{epochs} | "
            f"Training loss: {train_loss:.4f} | "
            f"Training acc: {train_acc:.4f} | "
            f"Validation loss: {validation_loss:.4f} | "
            f"Validation acc: {validation_acc:.4f}"
        )

    test_loss, test_acc = evaluate(model, test_loader, criterion, device)

    print(f"Test loss: {test_loss:.4f} | " f"Test acc: {test_acc:.4f}")
    return history


##### This is the solution to the debugging question
def evaluate(model, loader, criterion, device):
    model.eval()  # set the model in eval mode to disable dropout and batch norm statistics
    total_loss = 0.0
    correct = 0
    total = 0

    with torch.no_grad():
        for imgs, labels in tqdm(loader):
            imgs = imgs.to(device)
            labels = labels.to(device)

            outputs = model(imgs)
            loss = criterion(outputs, labels)

            total_loss += loss.item() * imgs.size(0)
            _, preds = outputs.max(1)
            correct += preds.eq(labels).sum().item()
            total += labels.size(0)

    avg_loss = total_loss / total
    acc = correct / total
    return avg_loss, acc


def split_dataset(
    dataset,
    seed,
    train_size=0.7,
    valid_size=0.2,
):
    train_size = int(train_size * len(dataset))
    validation_size = int(valid_size * len(dataset))
    test_size = len(dataset) - train_size - validation_size

    train_dataset, validation_dataset, test_dataset = random_split(
        dataset,
        [train_size, validation_size, test_size],
        generator=torch.Generator().manual_seed(seed),
    )
    return train_dataset, validation_dataset, test_dataset


def calculate_accuracy(model, loader, device):
    model.eval()
    # total_loss = 0.0
    correct = 0
    total = 0

    # This old to new dict maps the original indices of the dataset with those
    # of the new dataset that contains new classes. This shouldn't be known by
    # the students that's why it's manually implemented.
    old_to_new = {
        0: 0,
        1: 1,
        2: 2,
        3: 3,
        4: 4,
        5: 5,
        6: 7,
        7: 8,
        8: 9,
        9: 10,
        10: 11,
        11: 12,
        12: 13,
        13: 14,
        14: 16,
        15: 17,
        16: 18,
        17: 19,
        18: 21,
        19: 22,
    }

    with torch.no_grad():
        for imgs, labels in tqdm(loader):
            imgs = imgs.to(device)
            labels = labels.to(device)

            outputs = model(imgs)

            _, preds = outputs.max(1)
            # mask = torch.tensor([p.item() in old_to_new for p in preds])

            preds = torch.tensor([old_to_new[p.item()] for p in preds]).to(device)
            # break

            correct += preds.eq(labels).sum().item()
            total += labels.size(0)

    final_acc = correct / total

    return final_acc


def extract_predictions_E4(model, loader, device):
    model.eval()

    y_true = []
    y_pred = []

    # This old to new dict maps the original indices of the dataset with those
    # of the new dataset that contains new classes. This shouldn't be known by
    # the students that's why it's manually implemented.
    old_to_new = {
        0: 0,
        1: 1,
        2: 2,
        3: 3,
        4: 4,
        5: 5,
        6: 7,
        7: 8,
        8: 9,
        9: 10,
        10: 11,
        11: 12,
        12: 13,
        13: 14,
        14: 16,
        15: 17,
        16: 18,
        17: 19,
        18: 21,
        19: 22,
    }

    with torch.no_grad():
        for imgs, labels in loader:
            imgs = imgs.to(device)

            outputs = model(imgs)
            preds_old = torch.argmax(outputs, dim=1)

            preds_new = torch.tensor(
                [old_to_new[p.item()] for p in preds_old]  # type: ignore
            )

            y_true.append(labels.numpy())  # already new indices
            y_pred.append(preds_new.numpy())

    y_true = np.concatenate(y_true)
    y_pred = np.concatenate(y_pred)

    return y_true, y_pred
