import matplotlib.pyplot as plt
import seaborn as sns  # type: ignore
import numpy as np

sns.set()


def plot_dists(val_dict, color="C0", xlabel=None, stat="count", use_kde=True):
    columns = len(val_dict)
    fig, ax = plt.subplots(1, columns, figsize=(columns * 3, 2.5))
    fig_index = 0
    for key in sorted(val_dict.keys()):
        key_ax = ax[fig_index % columns]
        sns.histplot(
            val_dict[key],
            ax=key_ax,
            color=color,
            bins=50,
            stat=stat,
            kde=use_kde and ((val_dict[key].max() - val_dict[key].min()) > 1e-8),
        )  # Only plot kde if there is variance
        key_ax.set_title(
            f"{key} "
            + (
                r"(%i $\to$ %i)" % (val_dict[key].shape[1], val_dict[key].shape[0])
                if len(val_dict[key].shape) > 1
                else ""
            )
        )
        if xlabel is not None:
            key_ax.set_xlabel(xlabel)
        fig_index += 1
    fig.subplots_adjust(wspace=0.4)
    return fig


#### USED FOR OPTIMIZER/ACTIVATION QUESTIONS


def plot_learning_curves(results_dict, title_suffix=""):
    """
    Plot training loss and validation accuracy for multiple models.
    Args:
        results_dict: Dictionary with format {model_name: results}
                     where results is a dict with 'train_losses' and 'val_accuracies'
        title_suffix: Optional suffix for plot titles
    """
    plt.figure(figsize=(14, 5))

    # Plot training losses
    plt.subplot(1, 2, 1)
    for name, results in results_dict.items():
        plt.plot(results["train_loss"], label=name, linewidth=2)
    plt.xlabel("Epoch", fontsize=12)
    plt.ylabel("Training Loss", fontsize=12)
    plt.title(f"Training Loss Comparison {title_suffix}", fontsize=14)
    plt.legend(fontsize=11)
    plt.grid(True, alpha=0.3)

    # Plot validation accuracies
    plt.subplot(1, 2, 2)
    for name, results in results_dict.items():
        plt.plot(results["val_accuracy"], label=name, linewidth=2)
    plt.xlabel("Epoch", fontsize=12)
    plt.ylabel("Validation Accuracy", fontsize=12)
    plt.title(f"Validation Accuracy Comparison {title_suffix}", fontsize=14)
    plt.legend(fontsize=11)
    plt.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.show()


# Helper plotting function for debugging question
def plot_curve(history):
    """
    Plots the learning curves for accuracy and loss.

    history: Dictionary containing 'train_accuracy', 'val_accuracy', 'train_loss', 'val_loss' per epoch.
    """
    epochs = range(1, len(history["train_accuracy"]) + 1)

    plt.figure(figsize=(16, 5))

    # Accuracy Plot
    plt.subplot(1, 2, 1)
    plt.plot(epochs, history["train_accuracy"], label="Train Accuracy")
    plt.plot(epochs, history["val_accuracy"], label="Validation Accuracy")
    plt.ylim(0, 1)
    plt.xlabel("Epochs")
    plt.ylabel("Accuracy")
    plt.title("Accuracy Curve")
    plt.legend()

    # Loss Plot
    plt.subplot(1, 2, 2)
    plt.plot(epochs, history["train_loss"], label="Train Loss")
    plt.plot(epochs, history["val_loss"], label="Validation Loss")
    plt.ylim(0, 3.2)
    plt.xlabel("Epochs")
    plt.ylabel("Loss")
    plt.title("Loss Curve")
    plt.legend()

    plt.show()


def plot_confusion_matrix(
    cm,
    class_names,
    exercise,
    figsize=(14, 14),
    font_size=12,
    label_size=14,
    title_size=16,
):
    fmt = ".2g"
    if exercise == "E1":
        fmt = "d"
    elif exercise == "E3" or exercise == "E4":
        fmt = ".2f"

    title = "Confusion Matrix"

    fig, ax = plt.subplots(figsize=figsize)
    im = ax.imshow(cm, cmap="viridis")
    ax.grid(False)

    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    ax.set(
        xticks=np.arange(len(class_names)),
        yticks=np.arange(len(class_names)),
        xticklabels=class_names,
        yticklabels=class_names,
        xlabel="Predicted label",
        ylabel="True label",
        title=title,
    )

    ax.tick_params(axis="both", labelsize=label_size)
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right")

    # Annotate cells
    threshold = cm.max() / 2
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(
                j,
                i,
                format(cm[i, j], fmt),
                ha="center",
                va="center",
                fontsize=font_size,
                color="black" if cm[i, j] > threshold else "white",
            )

    fig.tight_layout()
    plt.show()
